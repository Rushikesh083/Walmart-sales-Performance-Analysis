WITH AverageFare AS (
    SELECT AVG(fare) AS avg_fare
    FROM titanic_dataset
)
SELECT t.*
FROM titanic_dataset t, AverageFare
WHERE t.fare > AverageFare.avg_fare;
