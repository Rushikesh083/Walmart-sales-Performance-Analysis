create view INFO AS
SELECT Passenger_No,survived,class,age,fare from titanic_dataset;

Select * from info;