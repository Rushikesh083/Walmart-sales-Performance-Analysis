DELIMITER //

CREATE PROCEDURE GetPassengersByAge(IN min_age INT, IN max_age INT)
BEGIN
    SELECT *
    FROM titanic_dataset
    WHERE age BETWEEN min_age AND max_age;
END //

DELIMITER ;

CALL GetPassengersByAge(20,50);