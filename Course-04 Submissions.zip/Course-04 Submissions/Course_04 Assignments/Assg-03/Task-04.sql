select *,
     CASE
           WHEN fare<=20000 then 'LOW'
           WHEN fare between 20000 and 60000 then 'MEDIUM'
           ELSE 'HIGH'
      END AS fare_category
from titanic_dataset;