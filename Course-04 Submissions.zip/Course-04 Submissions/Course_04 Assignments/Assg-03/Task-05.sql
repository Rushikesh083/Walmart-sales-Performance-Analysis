SELECT Passenger_No, fare,
       LEAD(fare) OVER (ORDER BY Passenger_No) AS next_fare
FROM titanic_dataset;