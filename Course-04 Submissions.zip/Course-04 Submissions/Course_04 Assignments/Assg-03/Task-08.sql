SELECT Passenger_No, fare,
       DENSE_RANK() OVER (ORDER BY fare DESC) AS ranks
FROM titanic_dataset;