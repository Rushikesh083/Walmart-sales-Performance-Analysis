SELECT Passenger_No, age,
       LAG(age) OVER (ORDER BY Passenger_No) AS previous_age
FROM titanic_dataset;