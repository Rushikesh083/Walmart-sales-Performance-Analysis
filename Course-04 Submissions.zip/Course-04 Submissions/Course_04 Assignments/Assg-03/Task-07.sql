SELECT Passenger_No, fare,
       RANK() OVER (ORDER BY fare DESC) AS ranks
FROM titanic_dataset;