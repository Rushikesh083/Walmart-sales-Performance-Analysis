SELECT Passenger_No, fare,
       ROW_NUMBER() OVER (ORDER BY fare DESC) AS row_numbers
FROM titanic_dataset;
