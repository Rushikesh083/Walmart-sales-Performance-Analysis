select * from titanic_dataset
order by age DESC
LIMIT 1;