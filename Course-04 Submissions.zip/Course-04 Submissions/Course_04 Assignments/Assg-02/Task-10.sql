SELECT 
    gs.GameID,
    gs.Platform,
    gs.SalesRegion,
    gs.UnitsSold,
    gs.Price
FROM 
    Game_Sales gs
WHERE 
    gs.SalesRegion IN ('North America', 'Europe');