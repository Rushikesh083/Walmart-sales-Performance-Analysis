select * from game_sales gs
LEFT JOIN games g
on g.GameID = gs.GameID
where g.GameID is NULL;