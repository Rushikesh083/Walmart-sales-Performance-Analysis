Insert into games(GameTitle,Genre,ReleaseDate,Developer)
values("Future Racing","Racing","2024-10-01","Speed Studios");

select * from games;