SELECT GameTitle, Platform, SalesRegion, UnitsSold
from games g
join game_sales gs
on g.GameID = gs.GameID;
