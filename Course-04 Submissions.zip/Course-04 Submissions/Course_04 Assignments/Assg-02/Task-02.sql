UPDATE game_sales
set Price=60
WHERE GameID=2;

SELECT * from game_sales;