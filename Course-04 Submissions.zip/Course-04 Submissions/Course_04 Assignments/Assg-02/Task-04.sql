select 
      g.GameTitle, gs.GameID, SUM(gs.UnitsSold) 
as 
      TotalUnitsSold
from 
      game_sales gs
JOIN 
      games g
on 
      gs.GameID=g.GameID
GROUP BY 
      gs.GameID, g.GameTitle
ORDER BY 
      TotalUnitsSold DESC;
