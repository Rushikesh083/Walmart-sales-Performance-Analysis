select  g.GameTitle, g.GameID, gs.SalesRegion, gs.UnitsSold from games g
JOIN game_sales gs on 
g.GameID = gs.GameID
where gs.SalesRegion="North America"
order by gs.UnitsSold DESC
LIMIT 1;