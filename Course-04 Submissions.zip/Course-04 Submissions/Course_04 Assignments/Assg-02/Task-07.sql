SELECT 
    g.GameID,
    g.GameTitle,
    g.Genre,
    g.ReleaseDate,
    g.Developer,
    gs.Platform,
    gs.SalesRegion,
    gs.UnitsSold,
    gs.Price
FROM Games g
LEFT JOIN Game_Sales gs ON g.GameID = gs.GameID
ORDER BY g.GameID;
