DELETE from game_sales 
WHERE GameID=5;

select * from game_sales;