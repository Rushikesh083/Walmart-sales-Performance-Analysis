SELECT Language, COUNT(*) AS Total_Titles
FROM Netflix_Originals
GROUP BY Language
HAVING COUNT(*) > 5;