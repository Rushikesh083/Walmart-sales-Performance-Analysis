Create schema sql_assg_01;
select *  from netflix_originals;

SELECT Title, GenreID, Runtime, IMDBScore, Language, Premiere_Date
FROM Netflix_Originals
WHERE IMDBScore > 7
  AND Runtime > 100
  AND Language IN ('English', 'Spanish');