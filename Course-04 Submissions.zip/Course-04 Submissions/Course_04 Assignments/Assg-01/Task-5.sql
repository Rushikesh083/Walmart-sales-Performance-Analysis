SELECT Title, GenreID, Runtime, IMDBScore, Language, Premiere_Date
FROM Netflix_Originals
WHERE Language IN ('English', 'Spanish', 'Hindi')
  AND Premiere_Date BETWEEN '01-01-2018' AND '31-12-2020';
