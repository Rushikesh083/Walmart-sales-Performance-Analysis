CREATE TABLE Netflix_Originals_Validated (
    Title VARCHAR(255),
    GenreID VARCHAR(50),
    Runtime INT CHECK (Runtime > 30),
    IMDBScore FLOAT CHECK (IMDBScore BETWEEN 0 AND 10),
    Language VARCHAR(50),
    Premiere_Date DATE
);

