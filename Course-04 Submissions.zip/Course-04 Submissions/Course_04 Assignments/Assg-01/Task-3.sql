select * from netflix_originals
where Language='Hindi'
order by Runtime desc, IMDBScore desc
limit 3;