SELECT Runtime, COUNT(*) AS Count
FROM Netflix_Originals
GROUP BY Runtime
ORDER BY Count DESC
LIMIT 5;