select * from netflix_originals
where Runtime<60 or IMDBScore<5
order by Premiere_Date;