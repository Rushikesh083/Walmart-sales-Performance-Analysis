SELECT Language, COUNT(*) AS Total_Titles
FROM Netflix_Originals
WHERE Premiere_Date between '01-01-2020' and '31-12-2020'
GROUP BY Language
ORDER BY Total_Titles DESC;
