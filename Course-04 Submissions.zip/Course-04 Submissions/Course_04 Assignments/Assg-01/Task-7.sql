SELECT GenreID, round(AVG(IMDBScore),2) AS Average_IMDBScore
FROM Netflix_Originals
GROUP BY GenreID
HAVING COUNT(*) >= 10;