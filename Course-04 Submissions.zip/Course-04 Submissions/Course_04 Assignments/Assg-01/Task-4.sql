select * from netflix_originals
where Title like '%House%' 
AND IMDBScore>6;